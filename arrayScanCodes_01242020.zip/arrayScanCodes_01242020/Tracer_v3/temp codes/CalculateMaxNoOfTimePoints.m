%% Calculate Max No of Time Points and total no of objects %%
tic;
NumTimePoints = [];
for i = 1: size(ConcatenatedData_Motile_Available,2);
    ColumnObjectLifetime= find(strcmpi('TrackObjects_Lifetime', ConcatenatedData_Motile_Available(i).Headers)); %Find column for Object Label%
    ColumnObjectLabel= find(strcmpi('TrackObjects_Label', ConcatenatedData_Motile_Available(i).Headers)); %Find column for Object Label%
    NumTimePoints(i) = max(ConcatenatedData_Motile_Available(i).Data(:,ColumnObjectLifetime));
    end
MaxNumTimePoints =max(NumTimePoints);
TotNumObjects = numel(cat(1,ConcatenatedData_Motile_Available.ObjectNumbers));
toc