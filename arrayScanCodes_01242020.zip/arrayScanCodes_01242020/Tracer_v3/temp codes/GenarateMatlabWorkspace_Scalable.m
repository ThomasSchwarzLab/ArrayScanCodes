%% Getting File Name
[filename, directory_name] = uigetfile( '*.csv', 'Select the first CSV file of the series' );
FullFileName = strcat(directory_name,filename);
[directory_name,filename,ext] = fileparts(FullFileName);
filename = [filename,ext];
%% loading Files %%
[pathToConcatenatedData_Unsorted] = LoadFilesToUnsortedStructuredArrayWOWellName(filename, directory_name);
[ConcatenatedData_Unsorted] = RemoveErroneousObjectsAndWells(pathToConcatenatedData_Unsorted);
assignin('base','ConcatenatedData_Unsorted',ConcatenatedData_Unsorted);
%% Genarating Sorted Structured Array %%
[ConcatenatedData_Motile, ConcatenatedData_Stationary, WellsAndFieldsPresent ] = GenarateSortedStructuredArray(ConcatenatedData_Unsorted);
assignin('base','ConcatenatedData_Motile',ConcatenatedData_Motile);
assignin('base','ConcatenatedData_Stationary',ConcatenatedData_Stationary);
assignin('base','WellsAndFieldsPresent',WellsAndFieldsPresent);
assignin('base','ConcatenatedData_Motile_thresholded',[]);
assignin('base','ConcatenatedData_Motile_unregistered',[]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Detect Registration Defects %%
[RegistrationDefects] = DetectRegistrationDefects( ConcatenatedData_Motile, ConcatenatedData_Stationary);
assignin ('base','RegistrationDefects',RegistrationDefects);
%% Saving Workspace 