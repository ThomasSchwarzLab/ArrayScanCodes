%% Shortening of Stationary Data %%
h = waitbar(0,'Removing Redundant Values from Stationary Mitos Data'); % initializing Waitbar %
for i = 1:  length (ConcatenatedData_Stationary)
    waitbar(i/length (ConcatenatedData_Stationary), h)
    Data = []; Headers = []; % Initializing Data and Headers temporary variables %
    Data = ConcatenatedData_Stationary(i).Data; % Loading up Data into temporary variable %
    Headers = ConcatenatedData_Stationary(i).Headers; % Loading up Headers  into temporary variable %
    
    if min(min(isnan(Data)))==0; % only enter this loop if there valid Data %
        % finding important column numbers
        ColumnObjectLabel= strmatch('TrackObjects_Label', Headers);
        ColumnObjectLifetime= strmatch('TrackObjects_Lifetime', Headers);
        % Sorting data %
        Data = sortrows(Data, ColumnObjectLifetime); % First sort data according to lifetime %
        Data = sortrows(Data, ColumnObjectLabel); % Then sort data according to object labels %
                % This causes the entire data to be sorted such all the objects appear together and clustered %
                % In each object cluster the lifetimes are sorted %
        % Finding Unique Objects % 
        ObjectLabels = Data(:,ColumnObjectLabel);
        ObjectNumbers = unique(ObjectLabels);
        % Finding the first occurances of each object labels %%
        [~,FirstIdx] = ismember(ObjectNumbers,ObjectLabels);
        FirstIdx = [FirstIdx; length(ObjectLabels)+1]; % Adding a last point to the list of "First indices" for further indexing %
                % This method allows for fast indexing of the single object data %    
        % Extracting Data for single objects %
        ObjectData = {};
        for i =1: length(ObjectNumbers);
            SingleObjectData = Data(FirstIdx(i):(FirstIdx(i+1)-1),:);
            ObjectData{i} = [SingleObjectData(1,:);SingleObjectData(end,:)];
        end
        Data=cat(1,ObjectData{:}); % Concatenating all cells to one data matrix %
        
        ConcatenatedData_Stationary(i).Data = Data; % Allocating data to original place %
    end
end
close(h); % Closing Waitbar%