
%% %% Shortening of Stationary Data %%
h = waitbar(0,'Removing Redundant Values from Stationary Mitos Data'); % initializing Waitbar %
for i = 1:  length (ConcatenatedData_Stationary)
    waitbar(i/length (ConcatenatedData_Stationary), h)
    Data = []; Headers = []; % Initializing Data and Headers temporary variables %
    Data = ConcatenatedData_Stationary(i).Data; % Loading up Data into temporary variable %
    Headers = ConcatenatedData_Stationary(i).Headers; % Loading up Headers  into temporary variable %
    
    if min(min(isnan(Data)))==0; % only enter this loop if there valid Data %
        % finding important column numbers
        ColumnObjectLabel= strmatch('TrackObjects_Label', Headers);
        ColumnObjectLifetime= strmatch('TrackObjects_Lifetime', Headers);
            
        UniqueObjects= unique(Data(:,ColumnObjectLabel)); % Find out number of Objects %
        MinLifetime = []; % Initialize variable for minimum lifetime %
        MaxLifetime = []; % Initialize variable for maximum lifetime %
        for j= 1:length (UniqueObjects)
            SingleObjectData = Data(Data(:,ColumnObjectLabel)== UniqueObjects(j),:); % Extract Data of Single Objects %
            MinLifetime = [MinLifetime; min(SingleObjectData(:,ColumnObjectLifetime))]; % Find Minimum object lifetimes %
            MaxLifetime = [MaxLifetime; max(SingleObjectData(:,ColumnObjectLifetime))]; % Find Maximum object lifetimes %
        end
        % Remove duplicate data %
        Data_OnlyFirstAndLast = NaN(length(UniqueObjects)*2, size(Data,2)); % Initializing Temporary variable for new data %
        k=1;
        for j = 1: length(UniqueObjects);
            Data_temp= Data(Data(:,ColumnObjectLabel) == UniqueObjects(j),:);
            Data_temp= Data_temp(Data_temp(:,ColumnObjectLifetime) == MinLifetime(j)| Data_temp(:,ColumnObjectLifetime) == MaxLifetime(j),:);
            Data_OnlyFirstAndLast(k:k+1,:)= Data_temp;
            k=k+2;
        end
        ConcatenatedData_Stationary(i).Data = Data_OnlyFirstAndLast; % Allocating data to original place %
    end
end
close(h); % Closing Waitbar%