function [Displacements,IntegratedDistances, ObjectNumbers]=GetObjectProperties(Data, Headers)
%% Getting Important Column Numbers %
ColumnObjectLabel= strmatch('TrackObjects_Label', Headers); %Find column for Object Label%
ColumnLocation_Center_X= strmatch('Location_Center_X', Headers); % Find column for X Location %
ColumnLocation_Center_Y= strmatch('Location_Center_Y', Headers); % Find column for Y Location %
ColumnObjectLifetime= strmatch('TrackObjects_Lifetime',Headers); % Find column for lifetime
%% Sorting According to Object Labels %
ObjectData = arrayfun(@(x) Data(Data(:,ColumnObjectLabel) == x, :), unique(Data(:,ColumnObjectLabel)), 'uniformoutput', false); %sort data into multiple cell arrays each containing data of individual objects%
ObjectData = cellfun(@(x) (sortrows(x,ColumnObjectLifetime)), ObjectData, 'uniformoutput', false);
% Calculating Displacements %
Displacements = cellfun(@(x) (((x(1,ColumnLocation_Center_X)-x(end,ColumnLocation_Center_X)))^2+ (x(1,ColumnLocation_Center_Y)-x(end,ColumnLocation_Center_Y))^2)^0.5,ObjectData, 'uniformoutput', false);
Displacements = cell2mat(Displacements);
%% Calculating Integrated Distances %
IntegratedDistances=[];
for i =1:length (ObjectData);
    SingleObjectData= ObjectData{i};
    IntegratedDistances (i,1) = max([0;cumsum(sqrt(diff(SingleObjectData(:,ColumnLocation_Center_X)).^2 + diff(SingleObjectData(:,ColumnLocation_Center_Y)).^2))]);
end
  
%% Finding Object Numbers %
ObjectNumbers = cellfun(@(x) (x(1,ColumnObjectLabel)) ,ObjectData, 'uniformoutput', false);
ObjectNumbers = cell2mat(ObjectNumbers);

end

