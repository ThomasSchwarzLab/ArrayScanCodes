WellNumber = ObjectProperties.IndividualFields.WellNumber(i);
FieldNumber = ObjectProperties.IndividualFields.FieldNumber(i);
Angles = ObjectProperties.InidividualObjects.FrameToFrameDisplacement_angle(FrameIdx_SingleField(j),(ObjectProperties.InidividualObjects.WellNumber == WellNumber & ObjectProperties.InidividualObjects.FieldNumber == FieldNumber));
Displacements = ObjectProperties.InidividualObjects.FrameToFrameDisplacement(FrameIdx_SingleField(j),(ObjectProperties.InidividualObjects.WellNumber == WellNumber & ObjectProperties.InidividualObjects.FieldNumber == FieldNumber));
% Finding out mean displacements excluding varying percentages of outliers %
MeanDisplacementsWoOutliers = zeros (1,99);
for k=1:99
    MeanDisplacementsWoOutliers(k) = trimmean(Displacements,k);
end
MeanDisplacementsWoOutliers  = MeanDisplacementsWoOutliers(isnan(MeanDisplacementsWoOutliers)==0);
[f2, gof] = fit( (1:length(MeanDisplacementsWoOutliers))', MeanDisplacementsWoOutliers', 'rat22' );figure;plot(f2, (1:length(MeanDisplacementsWoOutliers))', MeanDisplacementsWoOutliers')
disp (f2)
% Finding out mean displacements excluding varying percentages of outliers %
StdAnglesWoOutliers = zeros (1,99);
for k=1:99
StdAnglesWoOutliers(k) = stdWoOutliers(Angles,k);
end
figure;plot(StdAnglesWoOutliers)
StdAnglesWoOutliers  = StdAnglesWoOutliers(isnan(StdAnglesWoOutliers)==0);

[f2, gof] = fit( (1:length(StdAnglesWoOutliers))', StdAnglesWoOutliers', 'exp1' );figure;plot(f2, (1:length(StdAnglesWoOutliers))', StdAnglesWoOutliers')

fit_x = 1:100;
fit_y = f2.a*exp(f2.b*fit_x);
fit_y = fit_y-min(fit_y);
fit_y = fit_y./max(fit_y);
fit_x = fit_x(fit_y<0.01);
PercentageOfOutliers = fit_x(1)