
%% %% Shortening of Stationary Data %%
h = waitbar(0,'Removing Redundant Values from Stationary Mitos Data'); % initializing Waitbar %
for i = 1:  length (ConcatenatedData_Stationary)
    waitbar(i/length (ConcatenatedData_Stationary), h)
    Data = []; Headers = []; % Initializing Data and Headers temporary variables %
    Data = ConcatenatedData_Stationary(i).Data; % Loading up Data into temporary variable %
    Headers = ConcatenatedData_Stationary(i).Headers; % Loading up Headers  into temporary variable %
    
    if min(min(isnan(Data)))==0; % only enter this loop if there valid Data %
        % finding important column numbers
        ColumnObjectLabel= strmatch('TrackObjects_Label', Headers);
        ColumnObjectLifetime= strmatch('TrackObjects_Lifetime', Headers);
            
        ObjectData = arrayfun(@(x) Data(Data(:,ColumnObjectLabel) == x, :), unique(Data(:,ColumnObjectLabel)), 'uniformoutput', false); %sort data into multiple cell arrays each containing data of individual objects%
        ObjectData = cellfun(@(x) (sortrows(x,ColumnObjectLifetime)), ObjectData, 'uniformoutput', false); % Sort Data for each object according to lifetime %
        ObjectData = cellfun(@(x) ([x(1,:);x(end,:)]), ObjectData, 'uniformoutput', false); % Keep only the first and last lifetime data points %
        Data=cat(1,ObjectData{:}); % Concatenating all cells to one data matrix %
        
        ConcatenatedData_Stationary(i).Data = Data; % Allocating data to original place %
    end
end
close(h); % Closing Waitbar%