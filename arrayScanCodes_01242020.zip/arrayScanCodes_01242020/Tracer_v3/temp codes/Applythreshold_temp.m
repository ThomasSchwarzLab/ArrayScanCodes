%% Processing Data %%

Data_CumStd=NaN(length (Data),1);
for i =1:length (objectdisplacements);
    objectdisplacements_temp=Data; % making temporary variable for the loop %
    % making number of values divisible by i%
    while rem(length(objectdisplacements_temp),i)~=0; 
        objectdisplacements_temp=objectdisplacements_temp(1:end-1);
    end
    % reshaping the matrix to take every i number of values together into 1 row %
    objectdisplacements_reshaped = reshape(objectdisplacements_temp, length(objectdisplacements_temp)/i,i);
    
    % concatenating each row and then calculating the std of each row %
    objectdisplacements_reshaped_std = [];
    for j = 1: size(objectdisplacements_reshaped,1);
        objectdisplacements_reshaped_concatenated= cat(1,objectdisplacements_reshaped{j,1:i});
        objectdisplacements_reshaped_std_temp = std(objectdisplacements_reshaped_concatenated);
        objectdisplacements_reshaped_std=[objectdisplacements_reshaped_std;objectdisplacements_reshaped_std_temp];
    end
    Data_CumStd (i,1)= max(objectdisplacements_reshaped_std);
end
plot (1:length(objectdisplacements), Data_CumStd);