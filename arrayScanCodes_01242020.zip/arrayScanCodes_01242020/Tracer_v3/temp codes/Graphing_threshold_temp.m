function[HistCounts HistCenters]=ExponentialBinning(Data,BinIncrements)
edges = 10.^(0:0.01:max(Data));
h = histc(Displacements_All_Mitos_Mock, edges);
centers = sqrt(edges(1:end-1).*edges(2:end));
plot(centers,h(1:end-1));
xlim([0 50])
BinCounts = h(find(h,1,'first'):find(h,1,'last'));
BinCenters = centers(find(h,1,'first'):find(h,1,'last'));
BinWidths = edges(1:end-1)-edges(2:end);