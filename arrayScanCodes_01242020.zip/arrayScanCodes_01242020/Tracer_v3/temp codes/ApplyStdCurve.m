%% Get Mock Wells %%
[MockWells] = GetUserInputon96wellsThroughUItable(AvailableWells,'Select Mock Treated Wells');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Find out object parameters for each field matching mock wells %%
objectdisplacements={}; objectIntDistance={}; FieldPercentMotility=[]; % Initilizing Variables %
for i=1:length(ConcatenatedData_Motile)
    if max(ismember(MockWells, ConcatenatedData_Motile(i).WellName))==1 && min(min(isnan(ConcatenatedData_Motile(i).Data)))==0 && min(min(isnan(ConcatenatedData_Stationary(i).Data)))==0; %% Entering only if well name mataches and both stationary and motile fields have data %%
        [objectdisplacements_motile,objectIntDistance_motile, objectNumber_motile]=GetObjectProperties(ConcatenatedData_Motile(i).Data, ConcatenatedData_Motile(i).Headers);
        [~,~, objectNumber_Stationary]=GetObjectProperties(ConcatenatedData_Stationary(i).Data, ConcatenatedData_Stationary(i).Headers);
        if isempty(ConcatenatedData_Motile_thresholded) ==0;
            [objectdisplacements_thresholded,objectIntDistance_thresholded, objectNumber_Thresholded]=GetObjectProperties(ConcatenatedData_Motile_thresholded(i).Data, ConcatenatedData_Motile_thresholded(i).Headers);
        else objectdisplacements_thresholded=[];objectIntDistance_thresholded=[]; objectNumber_Thresholded = [];
        end
        objectdisplacements_temp={[objectdisplacements_motile;objectdisplacements_thresholded]};
        objectdisplacements = [objectdisplacements;objectdisplacements_temp];
        objectIntDistance_temp={[objectIntDistance_motile;objectIntDistance_thresholded]};
        objectIntDistance = [objectIntDistance;objectIntDistance_temp];
        FieldPercentMotility_temp= 100*length(objectNumber_motile)/(length(objectNumber_motile)+length(objectNumber_Stationary)+length(objectNumber_Thresholded));
        FieldPercentMotility = [FieldPercentMotility; FieldPercentMotility_temp];
       
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Getting Max STdev for increasing number of fields taken into consideration %%
objectdisplacements_cum_std = GetCumStdDev(objectdisplacements);
objectIntDistance_cum_std = GetCumStdDev(objectIntDistance);
FieldPercentMotility_cum_std = GetCumStdDev(FieldPercentMotility);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subplot(1,3,1);

plot(2:length(objectdisplacements_cum_std),objectdisplacements_cum_std(2:end), 'b--.');  xlabel('Number Of Fields'); ylabel('Standard Deviation');title('Displacement');
subplot(1,3,2);
plot(1:length(objectIntDistance_cum_std),objectIntDistance_cum_std(1:end), 'b--.');  xlabel('Number Of Fields'); ylabel('Standard Deviation');title('Integrated Distance');
subplot(1,3,3);
plot(1:length(FieldPercentMotility_cum_std),FieldPercentMotility_cum_std(1:end), 'b--.'); xlabel('Number Of Fields'); ylabel('Standard Deviation');title('Percent Motility');
zoom xon
hold off