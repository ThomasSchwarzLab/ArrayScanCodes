function findBestField()
%% Getting file names recursively in sub folders %%
format=cell2mat(inputdlg('Enter format of image files:','File Format', [1 50],{'TIF'}));
d = uigetdir(pwd, 'Select a folder');
oldFolder=cd;
cd (d);
files = dir(strcat('*.',format));

%% Extract file parts from name and add new fields %%
regExpRule_WellName='(?<=_)[A-Z]\d{2}(?=[f]\d{2})';
regExpRule_FieldName='(?<=_[A-Z]\d{2})[f]\d{2}(?=.)';
f = waitbar(0,'Please wait...'); % initializing waitbar
for fileNumber = 1:length(files)
    waitbar(fileNumber/length(files),f,strcat('reading image:', num2str(fileNumber), ' of :', num2str(length(files)))); % updating waitbar
    name=files(fileNumber).name;
    files(fileNumber).WellName=cell2mat(regexp(name,regExpRule_WellName,'match'));
    files(fileNumber).FieldName=cell2mat(regexp(name,regExpRule_FieldName,'match'));
    files(fileNumber).Image=imread(strcat(files(fileNumber).folder, filesep, files(fileNumber).name)); % bioformats importer
end

%% Extracting four quadrants %%
waitbar(1,f,'Extracting Quadrants'); % updating waitbar

% taking first quadrant of images from each copy %
Q1Images=cellfun(@(x) (x(1:size(x,1)/2,1:size(x,2)/2)),{files.Image},'un',0);
filesQ1=files;
[filesQ1.Image] = Q1Images{:};
quadrantName=repmat({'Q1'},1,size(filesQ1,1));
[filesQ1.quadrantName]=quadrantName{:};

% taking second quadrant of images from each copy %
Q2Images=cellfun(@(x) (x(1:size(x,1)/2,size(x,2)/2+1:end)),{files.Image},'un',0);
filesQ2=files;
[filesQ2.Image] = Q2Images{:};
quadrantName=repmat({'Q2'},1,size(filesQ2,1));
[filesQ2.quadrantName]=quadrantName{:};


% taking third quadrant of images from each copy %
Q3Images=cellfun(@(x) (x(size(x,1)/2+1:end,size(x,2)/2+1:end)),{files.Image},'un',0);
filesQ3=files;
[filesQ3.Image] = Q3Images{:};
quadrantName=repmat({'Q3'},1,size(filesQ3,1));
[filesQ3.quadrantName]=quadrantName{:};


% taking fourth quadrant of images from each copy %
Q4Images=cellfun(@(x) (x(size(x,1)/2+1:end,1:size(x,2)/2)),{files.Image},'un',0);
filesQ4=files;
[filesQ4.Image] = Q4Images{:};
quadrantName=repmat({'Q4'},1,size(filesQ4,1));
[filesQ4.quadrantName]=quadrantName{:};

%% concatenating four quadrants as different files %%
files=vertcat(filesQ1,filesQ2, filesQ3,filesQ4);
images=cat(3, files(:).Image);

%% Processing Images %%
waitbar(1,f,'Processing Images'); % updating waitbar

% Removing background and saturating %
medianOfImages=median(median(images,1),2);
images_NoBackground=images-medianOfImages;
images_Saturated=imadjustn(images_NoBackground,stretchlim(images_NoBackground(:)), [0.1 0.99]);

% binarizing Images %
bw=imbinarize(images_Saturated);
bw = bwareaopen(bw,1); % removing background from binary image

% Segmenting images %
cc=arrayfun(@(x) bwconncomp(bw(:,:,x),4),(1:size(bw,3))','un',0);

% calculating number of objects
numberOfObjects=arrayfun(@(x) cc{x,1}.NumObjects,(1:size(cc,1))','un',0);

% calculating object areas %
objectProperties = arrayfun(@(x) regionprops(cc{x,1},'basic'),(1:size(cc,1))','un',0);
medianAreas = arrayfun(@(x) median([objectProperties{x,1}.Area]),(1:size(objectProperties,1))','un',0);

% Calculating Intensities %
intensities = sum(sum(images,1),2); 
intensities = num2cell(squeeze(intensities(1,1,:)));

%% putting things back into the files variable%
[files.numberOfObjects]=numberOfObjects{:};
[files.medianArea]=medianAreas{:};
[files.intensity]=intensities{:};

%% Combining Quadrant and Field Nomenclature %%
quadrantName=[{files.FieldName}',{files.quadrantName}'];
quadrantName=arrayfun(@(x) horzcat(quadrantName{x,1}, ' ', quadrantName{x,2}),(1:size(quadrantName,1))','un',0);
[files.quadrantName] = quadrantName{:};

%% Restructuring data to group quadrant %%
[uniqueQuadrants, ~,uniqueQuadrantsIndexed]=unique({files.quadrantName});
for quadrantNumber = 1:length(uniqueQuadrants)
    waitbar(quadrantNumber/length(uniqueQuadrants),f,strcat('Sorting Quadrant:', num2str(quadrantNumber), ' of :', num2str(length(uniqueQuadrants)))); % updating waitbar
    filesSortedByQuadrants(quadrantNumber).data=files(uniqueQuadrantsIndexed==quadrantNumber);
    filesSortedByQuadrants(quadrantNumber).quadrantName=uniqueQuadrants(quadrantNumber);
end


%% Analyzing Quadrants and ouputting scores %%
waitbar(1,f,'Analyzing and scoring quadrants'); % updating waitbar

for quadrantNumber = 1:length(uniqueQuadrants)
    waitbar(quadrantNumber/length(uniqueQuadrants),f,strcat('Analyzing Field:', num2str(quadrantNumber), ' of :', num2str(length(uniqueQuadrants)))); % updating waitbar
    % Analysis of Number Of Objects %
    numberOfObjects=[filesSortedByQuadrants(quadrantNumber).data.numberOfObjects];
    filesSortedByQuadrants(quadrantNumber).dispersionOfnumberOfObjects=std(numberOfObjects)/mean(numberOfObjects);
    filesSortedByQuadrants(quadrantNumber).outlierCountsOfnumberOfObjects=sum(isoutlier(numberOfObjects));
    % Analysis of field intensity %
    intensity=[filesSortedByQuadrants(quadrantNumber).data.intensity];
    filesSortedByQuadrants(quadrantNumber).dispersionOfIntensity=std(intensity)/mean(intensity);
    filesSortedByQuadrants(quadrantNumber).outlierCountsOfIntensity=sum(isoutlier(intensity));
end
allAnalyses=horzcat([filesSortedByQuadrants.dispersionOfnumberOfObjects]',[filesSortedByQuadrants.outlierCountsOfnumberOfObjects]', [filesSortedByQuadrants.dispersionOfIntensity]', [filesSortedByQuadrants.outlierCountsOfIntensity]');

%% Genarating ranks (for all ranks issued: lower values mean lower ranks)%%
allAnalysesRank=zeros(size(allAnalyses));
for analysisNumber = 1:size(allAnalyses,2)
    % Analysis of Number Of Objects %
    data=allAnalyses(:,analysisNumber);
    data_sorted = sort(data);
    [~, allAnalysesRank(:,analysisNumber)] = ismember(data,data_sorted);
end
sumRanks=sum(allAnalysesRank,2);
finalRanks=sort(sumRanks);
[~, finalRanks] = ismember(sumRanks,finalRanks);
horzcat(num2cell(finalRanks),[filesSortedByQuadrants.quadrantName]');
close(f); % closing waitbar
%% Telling user about final ranks %%
% show as table
f = figure;
t = uitable('ColumnName', {'Rank', 'Field'});
drawnow;
set(t, 'Data', horzcat(compose('%02d',finalRanks),[filesSortedByQuadrants.quadrantName]'))
assignin('base','filesSortedByQuadrants', filesSortedByQuadrants)

%% Displaying quadrant positions Images %%
% Create figure
quadrantPositions = figure;
% Create textbox
annotation(quadrantPositions,'textbox',[0.0 0.55 0.45 0.45],'String','Q1','HorizontalAlignment','center','VerticalAlignment','middle','FontSize',64,'BackgroundColor',[1 1 1]);
annotation(quadrantPositions,'textbox',[0.55 0.55 0.45 0.45],'String','Q2','HorizontalAlignment','center','VerticalAlignment','middle','FontSize',64,'BackgroundColor',[1 1 1]);
annotation(quadrantPositions,'textbox',[0.55 0.0 0.45 0.45],'String','Q3','HorizontalAlignment','center','VerticalAlignment','middle','FontSize',64,'BackgroundColor',[1 1 1]);
annotation(quadrantPositions,'textbox',[0.0 0.0 0.45 0.45],'String','Q4','HorizontalAlignment','center','VerticalAlignment','middle','FontSize',64,'BackgroundColor',[1 1 1]);
cd(oldFolder);